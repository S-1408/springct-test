import React from 'react'

const Header = () => {
  return (
    <div className='header'><h1 >
        <span style={{color:'rgb(122, 180, 52)'}} >SPRING</span> <span style={{color:'white'}}>CT</span></h1></div>
  )
}

export default Header