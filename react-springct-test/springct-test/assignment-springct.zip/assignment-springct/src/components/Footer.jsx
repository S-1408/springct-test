import React from 'react'

const Footer = () => {
    return (
        <div className='header'><h5 >
            <span style={{color:'rgb(122, 180, 52)'}} >&#169; copyrights, All Rights Reserved!</span> </h5></div>
      )
}

export default Footer